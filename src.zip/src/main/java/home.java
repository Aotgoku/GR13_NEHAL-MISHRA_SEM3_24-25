

import java.awt.Image;
import java.io.File;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author main
 */
public class home extends javax.swing.JFrame {
  
    
  




    /**
     * Creates new form home
     */
    public home() {
        initComponents();
        File imageFile = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/search (1).png");
if (imageFile.exists()) {
    ImageIcon icon = new ImageIcon(imageFile.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (imageFile.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(imageFile.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(45, 45, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    jMenu6.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
}
File b2 = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/blood-type-o.png");
if (b2.exists()) {
    ImageIcon icon = new ImageIcon(b2.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (b2.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(b2.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(45, 45, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    jMenuItem6.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
}

 File s3 = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/IMG-20240731-WA0007.jpg");
if (s3.exists()) {
    ImageIcon icon = new ImageIcon(s3.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (s3.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(s3.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(45, 45, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    jMenuItem5.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
}
 
File exit = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/IMG-20240731-WA0011.jpg");
if (exit.exists()) {
    ImageIcon icon = new ImageIcon(exit.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (exit.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(exit.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(45, 45, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    jMenu5.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
}

       File ad = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/IMG-20240731-WA0008.jpg");
if (ad.exists()) {
    ImageIcon icon = new ImageIcon(ad.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (ad.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(ad.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(45, 45, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    jMenu1.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
}
  File stock = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/blood-bank.png");
if (stock.exists()) {
    ImageIcon icon = new ImageIcon(stock.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (stock.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(stock.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(45, 45, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    jMenu3.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
}
 File i = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/about.png");
if (i.exists()) {
    ImageIcon icon = new ImageIcon(i.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (i.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(i.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(45, 45, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    jButton1.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
}

   
   File BG = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/homebg2.jpg.png");
if (BG.exists()) {
    ImageIcon icon = new ImageIcon(BG.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (BG.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(BG.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(1126, 587, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    jLabel1.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
}
    File add = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/IMG-20240731-WA0015.jpg");
if (add.exists()) {
    ImageIcon icon = new ImageIcon(add.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (add.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(add.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(45, 45, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    jMenuItem1.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
} File up = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/IMG-20240731-WA0003.jpg");
if (up.exists()) {
    ImageIcon icon = new ImageIcon(up.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (up.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(up.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(45, 45, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    jMenuItem2.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
} File dtl = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/IMG-20240731-WA0016.jpg");
if (dtl.exists()) {
    ImageIcon icon = new ImageIcon(dtl.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (dtl.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(dtl.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(45, 45, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    jMenuItem3.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
} File ex = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/IMG-20240731-WA0012.jpg");
if (ex.exists()) {
    ImageIcon icon = new ImageIcon(ex.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (ex.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(ex.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(45, 45, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    jMenuItem11.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
} File lo = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/IMG-20240731-WA0017.jpg");
if (ad.exists()) {
    ImageIcon icon = new ImageIcon(lo.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (lo.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(lo.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(45, 45, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    jMenuItem10.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
} 


 File dlt = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/IMG-20240731-WA0004.jpg");
if (dlt.exists()) {
    ImageIcon icon = new ImageIcon(dlt.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (dlt.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(dlt.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(45, 45, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    jMenuItem12.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
} 
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem6 = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem12 = new javax.swing.JMenuItem();
        jMenu6 = new javax.swing.JMenu();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();
        jMenuItem10 = new javax.swing.JMenuItem();
        jMenuItem11 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 153, 153));
        jPanel1.setMaximumSize(new java.awt.Dimension(636, 370));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 490, 50, 40));

        jLabel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel1.setRequestFocusEnabled(false);
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1130, 560));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-1, 0, 1130, 560));

        jMenuBar1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jMenu3.setBackground(new java.awt.Color(255, 204, 204));
        jMenu3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jMenu3.setText("AVAILIABILITY");

        jMenuItem6.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_I, java.awt.event.InputEvent.ALT_DOWN_MASK));
        jMenuItem6.setText("BLOODTYPE");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem6);
        jMenu3.add(jSeparator2);

        jMenuBar1.add(jMenu3);

        jMenu1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jMenu1.setText("DONOR");

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        jMenuItem1.setText("ADD");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_U, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        jMenuItem2.setText("UPDATE ");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem3.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.ALT_DOWN_MASK));
        jMenuItem3.setText("DETAILS");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuItem12.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        jMenuItem12.setText("DELETE ");
        jMenuItem12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem12ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem12);

        jMenuBar1.add(jMenu1);

        jMenu6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jMenu6.setText("SEARCH DONOR");

        jMenuItem5.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_B, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        jMenuItem5.setText("BLOOD GROUP");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem5);

        jMenuBar1.add(jMenu6);

        jMenu5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jMenu5.setText("EXIT");

        jMenuItem10.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_L, java.awt.event.InputEvent.ALT_DOWN_MASK));
        jMenuItem10.setText("LOG OUT");
        jMenuItem10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem10ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem10);

        jMenuItem11.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        jMenuItem11.setText("EXIT APPLICATION");
        jMenuItem11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem11ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem11);

        jMenuBar1.add(jMenu5);

        setJMenuBar(jMenuBar1);

        setSize(new java.awt.Dimension(1126, 587));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
setVisible(false);
new Alldonordetails().setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
setVisible(false);
new AddDonor().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem11ActionPerformed
setVisible(false);        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem11ActionPerformed

    private void jMenuItem10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem10ActionPerformed
setVisible(false);
new LOGIN().setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem10ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
setVisible(false);
new Udatedonor().setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem12ActionPerformed
setVisible(false);
new Deletedonor().setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem12ActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
setVisible(false);
new bloodtype().setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
setVisible(false);
new search().setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
setVisible(false);
new About().setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new home().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem10;
    private javax.swing.JMenuItem jMenuItem11;
    private javax.swing.JMenuItem jMenuItem12;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    // End of variables declaration//GEN-END:variables
}
