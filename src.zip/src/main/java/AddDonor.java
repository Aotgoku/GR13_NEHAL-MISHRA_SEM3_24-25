
import java.awt.Image;
import java.io.File;
import java.sql.Connection;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.*;
import static javax.swing.UIManager.getInt;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author amank
 */

public class AddDonor extends javax.swing.JFrame {
    private int calculateAge(Date dob) {
    // Convert java.util.Date to LocalDate
    LocalDate birthDate = new java.sql.Date(dob.getTime()).toLocalDate();
    LocalDate currentDate = LocalDate.now();
    
    // Calculate age
    Period period = Period.between(birthDate, currentDate);
    return period.getYears();
}
 int getNextId() {
        int nextId = 1; // Default to 1 if no records are found
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection to the database
            String url = "jdbc:mysql://localhost:3306/blood2?zeroDateTimeBehavior=CONVERT_TO_NULL";
            con = DriverManager.getConnection(url, "root", "");

            // Create a statement object
            stmt = con.createStatement();

            // Execute the query to get the maximum ID
            String sql = "SELECT MAX(id) AS max_id FROM adddonor";
            rs = stmt.executeQuery(sql);

            // Process the result
            if (rs.next()) {
                int maxId = rs.getInt("max_id");
                nextId = maxId + 1; // Increment the ID for the next record
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        return nextId;
    }


   

    /**
     * Creates w form AddDonor
     */

void insertData() {
    // Initialize date formatter and convert date to string
    SimpleDateFormat s1 = new SimpleDateFormat("yyyy-MM-dd");
    String fdob = (dob != null) ? s1.format(dob) : null;  // Handle null date

    Connection con = null;
    PreparedStatement st = null;

    try {
        // Load the JDBC driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        String url = "jdbc:mysql://localhost:3306/blood2?zeroDateTimeBehavior=CONVERT_TO_NULL";
        con = DriverManager.getConnection(url, "root", "");

        // SQL query to insert data into the table
        String sql = "INSERT INTO adddonor (fname, faddress, fmobile, fdob, fblood, femail, fage, fgender,fbloodamount) VALUES (?, ?, ?, ?, ?, ?, ?, ?,?)";
        st = con.prepareStatement(sql);

        // Validate and set parameters for the prepared statement
        st.setString(1, fname);               // First parameter: fname
        st.setString(2, faddress);            // Second parameter: faddress
        
        // Validate and parse fmobile
        long mobileNumber = 0;
        try {
            mobileNumber = Long.parseLong(fmobile);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please enter a valid mobile number.");
            return;  // Exit the method if mobile number is invalid
        }
        st.setLong(3, mobileNumber);               // Third parameter: fmobile
        
        // Validate  fdob
        if (fdob == null) {
            JOptionPane.showMessageDialog(null, "Date of birth cannot be null.");
            return;  // Exit the method if date of birth is invalid
        }
        st.setString(4, fdob);                // Fourth parameter: fdob
        
        st.setString(5, fblood);              // Fifth parameter: fblood
        st.setString(6, femail);              // Sixth parameter: femail

        // Validate and parse fage
        int age = 0;
        try {
            age = Integer.parseInt(fage);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please enter a valid age.");
            return;  // Exit the method if age is invalid
        }
        st.setInt(7, age); 

        st.setString(8, fgender); 
                     
        st.setInt(9, fbloodamount);        


        int i = st.executeUpdate();

        if (i > 0) {
            JOptionPane.showMessageDialog(null, "Record inserted successfully");
        } else {
            JOptionPane.showMessageDialog(null, "Record not inserted successfully");
        }

    } catch (ClassNotFoundException | SQLException e) {
        e.printStackTrace();
    } finally {
        // Close resources
        try {
            if (st != null) st.close();
            if (con != null) con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

}


     
    public AddDonor() {
        initComponents();
        int defaultId = getNextId();
        jTextField1.setText(String.valueOf(defaultId));
        File exit = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/IMG-20240731-WA0017.jpg");
if (exit.exists()) {
    ImageIcon icon = new ImageIcon(exit.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (exit.exists()) {
    
    ImageIcon icon = new ImageIcon(exit.getAbsolutePath());
    
    
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(30, 30, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    
    btnreset.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
}
     File s = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/IMG-20240731-WA0003.jpg");
if (s.exists()) {
    ImageIcon icon = new ImageIcon(s.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (s.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(s.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(30, 30, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    btnsave.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
}
     File b2 = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/Back-Button-PNG-Image-Background.png");
if (b2.exists()) {
    ImageIcon icon = new ImageIcon(b2.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (b2.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(b2.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(30, 30, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    btnback.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
}
    
    
    }
private void id_autoincrement(){
try{
}catch(Exception e){JOptionPane.showMessageDialog(null, e);
}
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txtfname = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        btnsave = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jTextField6 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel11 = new javax.swing.JLabel();
        btnback = new javax.swing.JButton();
        btnreset = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jPanel1 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        fblood2 = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 204, 204));
        setForeground(new java.awt.Color(255, 153, 153));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(101, 38, 18, 0));

        txtfname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtfnameActionPerformed(evt);
            }
        });
        getContentPane().add(txtfname, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 120, 187, -1));

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECT GENDERS", "FEMALE", "MALE", "OTHERS" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 280, 174, -1));

        btnsave.setText("SAVE");
        btnsave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsaveActionPerformed(evt);
            }
        });
        getContentPane().add(btnsave, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 390, -1, -1));

        jLabel2.setText("D.O.B:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, 160, -1));

        jLabel3.setText("BLOOD GROUP:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, 96, -1));

        jLabel4.setText("AGE:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 240, 96, -1));

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CHOOSE", "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-" }));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, -1, -1));

        jTextField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField6ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 240, 71, -1));

        jLabel5.setText("DONOR ID:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 76, -1));

        jLabel6.setText("FULL NAME:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 75, 19));

        jLabel7.setText("GENDER:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, 56, 22));

        jLabel8.setText("ADDRESS:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 180, 56, -1));

        jLabel9.setText("MOBILE NO:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 80, 66, -1));

        jLabel10.setText("EMAIL ID:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 130, 66, -1));

        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 80, 103, -1));

        jTextField7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField7ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 180, 230, 60));

        jTextField8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField8ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField8, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 130, 289, -1));

        jSeparator1.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));
        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(363, 84, 10, 280));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel11.setText("ADD DONOR");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 20, -1, -1));

        btnback.setText("BACK");
        btnback.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbackActionPerformed(evt);
            }
        });
        getContentPane().add(btnback, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 390, -1, -1));

        btnreset.setText("RESET");
        btnreset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnresetActionPerformed(evt);
            }
        });
        getContentPane().add(btnreset, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 390, -1, -1));
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 80, 150, -1));
        getContentPane().add(jDateChooser1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 160, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 153, 153));
        jPanel1.setForeground(new java.awt.Color(255, 153, 153));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setText("BLOOD DONATED:");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 280, 110, -1));
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 13, -1, -1));

        fblood2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CHOOSE", "250", "500" }));
        jPanel1.add(fblood2, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 272, -1, 30));

        jLabel14.setText("ml");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 280, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 750, 440));

        setSize(new java.awt.Dimension(748, 438));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void btnsaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsaveActionPerformed
validation();
        if(validation())
        {
            insertData();
        }
        else
        {
            JOptionPane.showConfirmDialog(this,"validation issue");
        }
// TODO add your handling code here:
    }//GEN-LAST:event_btnsaveActionPerformed

    
    String fname,faddress,fmobile,femail,fage;
   
Date dob;
String fgender,fblood; int fbloodamount;
boolean validation()
        
{
    fname=txtfname.getText();
faddress=jTextField7.getText();
fmobile=jTextField5.getText();
fblood=(String)jComboBox2.getSelectedItem();
String bloodAmountStr = (String) fblood2.getSelectedItem();
try {
    fbloodamount = Integer.parseInt(bloodAmountStr);
} catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(this, "Please select a valid blood amount.");
    return false;
}

femail=jTextField8.getText();
fage=jTextField6.getText();
fgender=(String)jComboBox1.getSelectedItem();
dob=(Date) jDateChooser1.getDate();
if(faddress.equals(""))
{JOptionPane.showMessageDialog(this, "please enter the address first");
return false;
}
if(fblood.equals("CHOOSE"))
{JOptionPane.showMessageDialog(this, "please enter the BLOOD GROUP first");
return false;
}
if(fblood2.equals("CHOOSE"))
{
    JOptionPane.showMessageDialog(this, "please enter the amount of blood donated ");
    return false;
}

if (fmobile.equals("")) {
            JOptionPane.showMessageDialog(null, "Please enter the mobile number of the donor");
            return false;
        }

        // Define the regex pattern for a valid 10-digit mobile number
        String regex = "^[6-9]\\d{9}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(fmobile);

        // Check if the mobile number is valid
        if (!matcher.matches()) {
            JOptionPane.showMessageDialog(null, "Invalid mobile number. Please enter a 10-digit number starting with 6-9.");
            return false;
        }

if(dob.equals(null))
{JOptionPane.showMessageDialog(this, "please enter the d.o.b");
return false;}
int age = calculateAge(dob);
    
    // Set age in the text field or validate as needed
    jTextField6.setText(String.valueOf(age));
    
if(fgender==null)
{JOptionPane.showMessageDialog(this, "please enter the gender of the donor...");
return false;}
if(fblood==null)
{JOptionPane.showMessageDialog(this, "please enter the blood type of the donor...");
return false;}
return true;


}
    private void jTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField6ActionPerformed

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField5ActionPerformed

    private void jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField8ActionPerformed

    private void txtfnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtfnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtfnameActionPerformed

    private void jTextField7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField7ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void btnresetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnresetActionPerformed
setVisible(false);
new AddDonor().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_btnresetActionPerformed

    private void btnbackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbackActionPerformed
setVisible(false);  
new home().setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_btnbackActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AddDonor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AddDonor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AddDonor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AddDonor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddDonor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnback;
    private javax.swing.JButton btnreset;
    private javax.swing.JButton btnsave;
    private javax.swing.JComboBox<String> fblood2;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField txtfname;
    // End of variables declaration//GEN-END:variables
}
