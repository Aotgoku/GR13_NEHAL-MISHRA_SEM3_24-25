
import java.awt.Image;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author amank
 */
public class Deletedonor extends javax.swing.JFrame {
    private void deleteDonorInfo(int id) {
    Connection con = null;
    PreparedStatement pst = null;

    try {
        // Load the JDBC driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        String url = "jdbc:mysql://localhost:3306/blood2?zeroDateTimeBehavior=CONVERT_TO_NULL";
        con = DriverManager.getConnection(url, "root", "");

        // Prepare the SQL DELETE statement
        String sql = "DELETE FROM adddonor WHERE id = ?";
        pst = con.prepareStatement(sql);
        pst.setInt(1, id);

        // Execute the delete
        int rowsDeleted = pst.executeUpdate();

        if (rowsDeleted > 0) {
            JOptionPane.showMessageDialog(this, "Donor record deleted successfully.");
        } else {
            JOptionPane.showMessageDialog(this, "No donor found with ID: " + id);
        }

    } catch (ClassNotFoundException | SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "An error occurred while deleting the donor record.");
    } finally {
        // Close resources
        try {
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
    void loadDonorInfo(int id) {
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    try {
        // Load the JDBC driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        String url = "jdbc:mysql://localhost:3306/blood2?zeroDateTimeBehavior=CONVERT_TO_NULL";
        con = DriverManager.getConnection(url, "root", "");

        // Prepare the SQL query
        String sql = "SELECT * FROM adddonor WHERE id = ?";
        pst = con.prepareStatement(sql);
        pst.setInt(1, id);

        // Execute the query
        rs = pst.executeQuery();

        // Populate the fields if the donor exists
        if (rs.next()) {
            txtfname.setText(rs.getString("fname"));
            jTextField7.setText(rs.getString("faddress"));
            jTextField5.setText(rs.getString("fmobile"));
            jTextField8.setText(rs.getString("femail"));
            jTextField6.setText(String.valueOf(rs.getInt("fage")));
            jComboBox2.setSelectedItem(rs.getString("fblood"));
            jComboBox1.setSelectedItem(rs.getString("fgender"));
            jDateChooser1.setDate(rs.getDate("fdob"));
        } else {
            JOptionPane.showMessageDialog(this, "No donor found with ID: " + id);
        }

    } catch (ClassNotFoundException | SQLException e) {
        e.printStackTrace();
    } finally {
        // Close resources
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
    void updateDonorInfo(int id) {
    Connection con = null;
    PreparedStatement pst = null;

    try {
        // Load the JDBC driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        String url = "jdbc:mysql://localhost:3306/blood2?zeroDateTimeBehavior=CONVERT_TO_NULL";
        con = DriverManager.getConnection(url, "root", "");

        // Prepare the SQL update statement
        String sql = "UPDATE adddonor SET fname = ?, faddress = ?, fmobile = ?, fdob = ?, fblood = ?, femail = ?, fage = ?, fgender = ? WHERE id = ?";
        pst = con.prepareStatement(sql);

        // Set the parameters
        pst.setString(1, txtfname.getText());
        pst.setString(2, jTextField7.getText());
        pst.setString(3, jTextField5.getText());
        pst.setDate(4, new java.sql.Date(jDateChooser1.getDate().getTime()));
        pst.setString(5, (String) jComboBox2.getSelectedItem());
        pst.setString(6, jTextField8.getText());
        pst.setInt(7, Integer.parseInt(jTextField6.getText()));
        pst.setString(8, (String) jComboBox1.getSelectedItem());
        pst.setInt(9, id);

        // Execute the update
        int rowsUpdated = pst.executeUpdate();

        if (rowsUpdated > 0) {
            JOptionPane.showMessageDialog(this, "Donor information updated successfully.");
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update donor information.");
        }

    } catch (ClassNotFoundException | SQLException e) {
        e.printStackTrace();
    } finally {
        // Close resources
        try {
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}

    /**
     * Creates new form Udatedonor
     */
    public Deletedonor() {
        initComponents();
         File stock = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/back.png.png");
if (stock.exists()) {
    ImageIcon icon = new ImageIcon(stock.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (stock.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(stock.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(30, 30, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    jButton2.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
}
         File dlt = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/IMG-20240731-WA0004.jpg");
if (dlt.exists()) {
    ImageIcon icon = new ImageIcon(dlt.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (dlt.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(dlt.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(30, 30, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    jButton4.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
} 
 File back2 = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/search-1.jpng");
if (back2.exists()) {
    ImageIcon icon = new ImageIcon(back2.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (back2.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(back2.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(30, 30, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    jButton3.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
}
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtfname = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jTextField6 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel11 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 153, 153));
        setLocation(new java.awt.Point(330, 140));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtfname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtfnameActionPerformed(evt);
            }
        });
        getContentPane().add(txtfname, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 100, 187, -1));

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECT GENDER", "FEMALE", "MALE", "OTHERS" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 260, 174, -1));
        getContentPane().add(jDateChooser1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, -1, -1));

        jLabel2.setText("D.O.B:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 140, 70, -1));

        jLabel3.setText("BLOOD GROUP:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 96, -1));

        jLabel4.setText("AGE:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 80, -1));

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "A+", "A-", "B+", "AB+", "B-", "O+", "O-" }));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 180, -1, -1));

        jTextField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField6ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 220, 71, -1));

        jLabel6.setText("FULL NAME:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, 75, 19));

        jLabel7.setText("GENDER:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, 56, 22));

        jLabel8.setText("ADDRESS:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 200, 56, -1));

        jLabel9.setText("MOBILE NO:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 100, -1, -1));

        jLabel10.setText("EMAIL ID:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 150, 66, -1));

        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 100, 103, -1));

        jTextField7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField7ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 200, 230, 60));

        jTextField8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField8ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField8, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 150, 289, 40));

        jSeparator1.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));
        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 70, 10, 280));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel11.setText("DELETE DONOR DETAILS");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 0, -1, -1));
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 40, 150, -1));

        jButton2.setText("BACK");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 370, -1, -1));

        jButton3.setText("SEARCH DONOR");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 40, -1, -1));

        jButton4.setText("DELETE");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 370, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 102, 102));
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 760, 420));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtfnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtfnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtfnameActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField6ActionPerformed

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField5ActionPerformed

    private void jTextField7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField7ActionPerformed

    private void jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField8ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
setVisible(false);
new home().setVisible(true);
// TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

    try {
        int id = Integer.parseInt(jTextField1.getText());
        loadDonorInfo(id);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Please enter a valid ID.");
    }

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
try {
        int id = Integer.parseInt(jTextField1.getText());
        
        // Call method to delete donor record
        deleteDonorInfo(id);
        
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Please enter a valid ID.");
    }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Udatedonor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Udatedonor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Udatedonor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Udatedonor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Udatedonor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField txtfname;
    // End of variables declaration//GEN-END:variables
}
