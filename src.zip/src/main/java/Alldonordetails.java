/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
import java.awt.Image;
import java.io.File;
import java.sql.Connection;
import java.sql.*;
import java.text.MessageFormat;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.Vector;
/**
 *
 * @author amank
 */
public class Alldonordetails extends javax.swing.JFrame {
    private void loadDonorData() {
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;

        // DefaultTableModel to manage table rows and columns
        DefaultTableModel model = (DefaultTableModel) donorTable.getModel();

        try {
            // Load the JDBC driver and establish connection to the database
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/blood2?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "");

            // Create a statement object and execute a query to fetch all donors
            stmt = con.createStatement();
            String query = "SELECT * FROM adddonor";
            rs = stmt.executeQuery(query);

            // Loop through the result set and add rows to the table
            while (rs.next()) {
                // Create a row for each donor
                Object[] row = {
                    rs.getInt("id"),
                    rs.getString("fname"),
                    rs.getString("faddress"),
                    rs.getString("fmobile"),
                    rs.getString("fdob"),
                    rs.getString("fblood"),
                    rs.getString("femail"),
                    rs.getInt("fage"),
                    rs.getString("fgender"),
                     // Added missing comma
                };

                // Add the row to the table model
                model.addRow(row);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                // Close resources
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


     
    public Alldonordetails() {
        initComponents();
         loadDonorData(); 
         File exit = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/IMG-20240731-WA0017.jpg");
if (exit.exists()) {
    ImageIcon icon = new ImageIcon(exit.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (exit.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(exit.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(45, 45, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    jButton3.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
}
  File s2 = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/Back-Button-PNG-Image-Background.png");
if (s2.exists()) {
    ImageIcon icon = new ImageIcon(s2.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (s2.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(s2.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(45, 45, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    jButton2.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
} File stock = new File("C:/Users/amank/OneDrive/Documents/NetBeansProjects/BBMSLOGINPAGE/src/main/java/project/images/printf.png");
if (stock.exists()) {
    ImageIcon icon = new ImageIcon(stock.getAbsolutePath());
} else {
    System.out.println("Image file not found at the specified location.");
}
if (stock.exists()) {
    // Load the image
    ImageIcon icon = new ImageIcon(stock.getAbsolutePath());
    
    // Resize the image
    Image img = icon.getImage();
    Image resizedImage = img.getScaledInstance(45, 45, java.awt.Image.SCALE_SMOOTH); // Adjust width and height as needed
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    
    // Set the resized icon to jMenuItem6
    jButton1.setIcon(resizedIcon);

} else {
    System.out.println("Image file not found at the specified location.");
}
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        donorTable = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 153, 153));
        setLocation(new java.awt.Point(340, 130));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        donorTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "NAME", "ADDRESS", "MOBILE", "DOB", "BLOOD", "EMAIL", "AGE", "GENDER"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Long.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        donorTable.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                donorTableComponentShown(evt);
            }
        });
        jScrollPane1.setViewportView(donorTable);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 58, 920, 275));

        jPanel2.setBackground(new java.awt.Color(255, 102, 102));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("ALL DONOR DETAILS");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 10, 280, 30));

        jButton3.setText("CLOSE");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 370, -1, -1));

        jButton2.setText("BACK");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 370, -1, -1));

        jButton1.setText("PRINT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 370, -1, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 940, 450));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void donorTableComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_donorTableComponentShown
        // TODO add your handling code here:
    }//GEN-LAST:event_donorTableComponentShown

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
setVisible(false);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
setVisible(false);
new home().setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
try {
        // Print the table
        boolean complete = donorTable.print(JTable.PrintMode.FIT_WIDTH, 
                                            new MessageFormat("Donor Details"), 
                                            new MessageFormat("Page {0}"));
        if (complete) {
            JOptionPane.showMessageDialog(null, "Printing Complete", "Information", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Printing Cancelled", "Information", JOptionPane.INFORMATION_MESSAGE);
        }
    } catch (java.awt.print.PrinterException e) {
        JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Alldonordetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Alldonordetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Alldonordetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Alldonordetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Alldonordetails().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable donorTable;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
